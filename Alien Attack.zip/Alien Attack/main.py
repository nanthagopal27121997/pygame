import pygame
import random
import math

from pygame import mixer

# indicate the pygame
pygame.init()

# create the screen
screen = pygame.display.set_mode((900, 640))

# Background
background = pygame.image.load('background.png')


# Tile and Icon
pygame.display.set_caption("Alien Attack")
icon = pygame.image.load('icon.png')
pygame.display.set_icon(icon)


# start


# player
playerImg = pygame.image.load('player.png')
playerX = 370
playerY = 480
playerx_change = 0

# enemy
enemyImg = []
enemyX = []
enemyY = []
enemyX_change = []
enemyY_change = []
noofenemy = 4
for i in range(noofenemy):

    enemyImg.append(pygame.image.load('alien.png'))
    enemyX.append(random.randint(0, 900))
    enemyY.append(random.randint(50, 150))
    enemyX_change.append(2)
    enemyY_change.append(50)

# ready - you can't see the bullet on the screeen
# fire - The bullet is currently moving

bulletImg = pygame.image.load('bullet.png')
bulletX = 0
bulletY = 480
bulletX_change = 1
bulletY_change = 10
bullet_state = "ready"

#score = 0

score_value = 0
font = pygame.font.Font('freesansbold.ttf',32)

textX = 10
textY = 10

enter = True

def show_score(x,y):
    score = font.render("score:" + str(score_value),True,(255,255,255))
    screen.blit(score,(x,y))


#game over

over_font = pygame.font.Font('freesansbold.ttf', 64)

def game_over_text():
    over_text = over_font.render("GAME OVER ", True, (255, 255, 255))
    screen.blit(over_text, (400, 300))


#start

def start_display():
    start_text = over_font.render("press s to start", True, (255,255,255))
    screen.blit(start_text, (400,300))

def pause():
    paused = True
    while paused:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c:
                    paused = False


def player(x, y):
    screen.blit(playerImg, (x, y))


def enemy(x, y, i):
    screen.blit(enemyImg[i], (x, y))



def fire_bullet(x, y):
    global bullet_state
    bullet_state = "fire"
    screen.blit(bulletImg, (x + 16, y + 10))


def isCollision(enemyX,enemyY,bulletX,bulletY):
   distance = math.sqrt((math.pow(enemyX-bulletX,2))+(math.pow(enemyY-bulletY,2)))
   if distance <27:
       return True
   else:
       return False






# game loop only close when a close  button is pressed

running = True
while running:

    # RGB - Red, Green, Blue
    screen.fill((255, 255, 255))

    # background Image
    screen.blit(background,(0,0))


    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False


        if enter is True:
            while enter:
                start_display()
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        quit()
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_s:
                            enter = False


        # If keystroke is pressed is left or right
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                playerx_change = -2
            if event.key == pygame.K_RIGHT:
                playerx_change = 2
            if event.key == pygame.K_SPACE:
                #bulletSound = mixer.Sound("laser.wav")
                #bulletSound.play()
                if bullet_state is "ready":
                    # get the current x cordinate of the spaceship
                    bulletX = playerX
                    fire_bullet(playerX, bulletY)
            if event.key == pygame.K_p:
                pause()
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                playerx_change = 0

    # 5= 5+0.1 = 5.1
    # 5 = 5-0.1 = 4.9
    # boundary for player
    playerX += playerx_change

    if playerX <= 0:
        playerX = 0
    elif playerX >= 900:
        playerX = 900

    # 5= 5+0.1 = 5.1
    # 5 = 5-0.1 = 4.9
    # enemy for player

    # Game Over
    for i in range (noofenemy):
        if enemyY[i] > 400:
            for j in range (noofenemy):
                enemyY[j] = 650
                game_over_text()
        enemyX[i] += enemyX_change[i]

        if enemyX[i] <= 0:
            enemyX_change[i] = 4
            enemyY[i] += enemyY_change[i]
        elif enemyX[i] >= 850:
            enemyX_change[i] = -4
            enemyY[i] += enemyY_change[i]

        enemy(enemyX[i],enemyY[i],i)

        collision = isCollision(enemyX[i], enemyY[i], bulletX, bulletY)
        if collision:
            explosionSound = mixer.Sound("explosion.wav")
            explosionSound.play()
            bulletY = 480
            bullet_state = "ready"
            score_value += 1
            enemyX[i] = random.randint(0, 650)
            enemyY[i] = random.randint(50, 150)

    # Bullet movement
    if bulletY <= 0:
        bulletY = 480
        bullet_state = "ready"
    if bullet_state is "fire":
        fire_bullet(bulletX, bulletY)
        bulletY -= bulletY_change

    #collision


    player(playerX, playerY)
    
    show_score(textX,textY)
    pygame.display.update()