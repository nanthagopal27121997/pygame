def say_hello():
    '''
    Prints hello string when run from command line
    '''
    print("hello")

if __name__ == '__main__':
    say_hello()