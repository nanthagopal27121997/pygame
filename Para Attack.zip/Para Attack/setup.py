from cx_Freeze import setup, Executable
setup(name = "pythonCX_Freeze" ,
   version = "0.1" ,
   description = "" ,
   executables = [Executable("pythonCX_Freeze.py")])